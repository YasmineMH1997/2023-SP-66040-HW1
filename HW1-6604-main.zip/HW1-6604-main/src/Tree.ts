import * as d3 from 'd3'
export function getRootFromData(data,{ // data is either tabular (array of objects) or hierarchy (nested objects)
  path, // as an alternative to id and parentId, returns an array identifier, imputing internal nodes
  id = Array.isArray(data) ? d => d.id : null, // if tabular data, given a d in data, returns a unique identifier (string)
  parentId = Array.isArray(data) ? d => d.parentId : null, // if tabular data, given a node d, returns its parent’s identifier
  children, // if hierarchical data, given a d in data, returns its children
  tree = d3.tree, // layout algorithm (typically d3.tree or d3.cluster)
  sort, // how to sort nodes prior to layout (e.g., (a, b) => d3.descending(a.height, b.height))
  label, // given a node d, returns the display name
  title, // given a node d, returns its hover text
  link, // given a node d, its link (if any)
  linkTarget = "_blank", // the target attribute for links (if any)
  width = 640, // outer width, in pixels
  height = 400, // outer height, in pixels
  r = 3, // radius of nodes
  padding = 1, // horizontal padding for first and last column
  fill = "#999", // fill for nodes
  fillOpacity, // fill opacity for nodes
  stroke = "#555", // stroke for links
  strokeWidth = 1.5, // stroke width for links
  strokeOpacity = 0.4, // stroke opacity for links
  strokeLinejoin, // stroke line join for links
  strokeLinecap, // stroke line cap for links
  halo = "#fff", // color of label halo 
  haloWidth = 3, // padding around the labels
  curve = d3.curveBumpX, // curve for the link
} = {}, links = []){

  const root = path != null ? d3.stratify().path(path)(data)
        : id != null || parentId != null ? d3.stratify().id(id).parentId(parentId)(data)
        : d3.hierarchy(data, children);

  return root

}

// Copyright 2021 Observable, Inc.
// Released under the ISC license.
// https://observablehq.com/@d3/tree
export function Tree(data, { // data is either tabular (array of objects) or hierarchy (nested objects)
    path, // as an alternative to id and parentId, returns an array identifier, imputing internal nodes
    id = Array.isArray(data) ? d => d.id : null, // if tabular data, given a d in data, returns a unique identifier (string)
    parentId = Array.isArray(data) ? d => d.parentId : null, // if tabular data, given a node d, returns its parent’s identifier
    children, // if hierarchical data, given a d in data, returns its children
    tree = d3.tree, // layout algorithm (typically d3.tree or d3.cluster)
    sort, // how to sort nodes prior to layout (e.g., (a, b) => d3.descending(a.height, b.height))
    label, // given a node d, returns the display name
    title, // given a node d, returns its hover text
    link, // given a node d, its link (if any)
    linkTarget = "_blank", // the target attribute for links (if any)
    width = 2000, // outer width, in pixels
    height = 2000, // outer height, in pixels
    r = 3, // radius of nodes
    padding = 1, // horizontal padding for first and last column
    fill = "#999", // fill for nodes
    fillOpacity, // fill opacity for nodes
    stroke = "#555", // stroke for links
    strokeWidth = 1.5, // stroke width for links
    strokeOpacity = 0.4, // stroke opacity for links
    strokeLinejoin, // stroke line join for links
    strokeLinecap, // stroke line cap for links
    halo = "#fff", // color of label halo 
    haloWidth = 3, // padding around the labels
    curve = d3.curveBumpX, // curve for the link
    
  } = {}, links = [], lca = null, printNode, extraLinks=[],simulateCalls,simulateMoves) {
  
    // If id and parentId options are specified, or the path option, use d3.stratify
    // to convert tabular data to a hierarchy; otherwise we assume that the data is
    // specified as an object {children} with nested objects (a.k.a. the “flare.json”
    // format), and use d3.hierarchy.
    const root = path != null ? d3.stratify().path(path)(data)
        : id != null || parentId != null ? d3.stratify().id(id).parentId(parentId)(data)
        : d3.hierarchy(data, children);
    
    const d = root.descendants()
    //console.log(d)
    const l = d.length
    //console.log(root.links())
    //root.links(root.links().push({source: d[l-2], target: d[l-1]}))
    //console.log({source: d[l-2], target: d[l-1]})
    // Sort the nodes.
    if (sort != null) root.sort(sort);
  
    // Compute labels and titles.
    const descendants = root.descendants();
    const L = label == null ? null : descendants.map(d => label(d.data, d));
  
    // Compute the layout.
    const dx = 10;
    const dy = width / (root.height + padding);
    tree().nodeSize([dx, dy])(root);
  
    // Center the tree.
    let x0 = Infinity;
    let x1 = -x0;
    root.each(d => {
      if (d.x > x1) x1 = d.x;
      if (d.x < x0) x0 = d.x;
    });
  
    // Compute the default height.
    if (height === undefined) height = x1 - x0 + dx * 2;
  
    // Use the required curve
    if (typeof curve !== "function") throw new Error(`Unsupported curve`);
  
    const svg = d3.create("svg")
        .attr("viewBox", [-dy * padding / 2, x0 - dx, width, height])
        .attr("width", width)
        .attr("height", height)
        .attr("style", "max-width: 100%; height: auto; height: intrinsic;")
        .attr("font-family", "sans-serif")
        .attr("font-size", 12);
  
    var linksToDraw = root.links()
    console.log("redLinksTree",extraLinks)
    const actualExtraLinksToDraw = extraLinks.map((link)=> ({
      source: linksToDraw.filter(l => l.source.data.name === link.source.data.name)[0].source,
      target: linksToDraw.filter(l => l.target.data.name === link.target.data.name)[0].target
    }))
    
    linksToDraw = linksToDraw.concat(actualExtraLinksToDraw)
    
    svg.append("g")
  .attr("fill", "none")
  .attr("stroke", stroke)
  .attr("stroke-opacity", strokeOpacity)
  .attr("stroke-linecap", strokeLinecap)
  .attr("stroke-linejoin", strokeLinejoin)
  .attr("stroke-width", strokeWidth)
.selectAll("path")
  .data(linksToDraw)
  .join("path")
    .attr("d", d3.link(curve)
        .x(d => d.y)
        .y(d => d.x))
    .style("stroke", d => {
      if (actualExtraLinksToDraw.some(extraLink => extraLink.source === d.source && extraLink.target === d.target)) {
        return "red";
      } else if (links.filter(temp => parseInt(temp.source.data.name) === parseInt(d.source.data.name) && parseInt(temp.target.data.name) === parseInt(d.target.data.name)).length === 1) {
        return "blue";
      } else {
        return stroke;
      }
    })
    .style("stroke-width", d => {
      if (actualExtraLinksToDraw.some(extraLink => extraLink.source === d.source && extraLink.target === d.target)) {
        return "3px"; // increase the width for red links
      } else {
        return links.filter(temp => parseInt(temp.source.data.name) === parseInt(d.source.data.name) && parseInt(temp.target.data.name) === parseInt(d.target.data.name)).length === 1 ? "4px" : "1px";
      }
    });

    const node = svg.append("g")
      .selectAll("a")
      .data(root.descendants())
      .join("a")
        .attr("xlink:href", link == null ? null : d => link(d.data, d))
        .attr("target", link == null ? null : linkTarget)
        .attr("transform", d => `translate(${d.y},${d.x})`); // Attach click event listener;
      
       
    
    node.append("circle")
        .attr("fill", d => d.children ? stroke : fill)
        //.attr("r", d => d.data.name == lca?.data?.name ? 6 : r);
        .attr("r", d => d.data.replicas.length > 3 ? d.data.replicas.length: 3)
    node.on('click', (d) => printNode(d))
  
    if (title != null) node.append("title")
        .text(d => title(d.data, d));
  
    if (L) node.append("text")
        .attr("dy", "0.32em")
        .attr("x", d => d.children ? -6 : 6)
        .attr("text-anchor", d => d.children ? "end" : "start")
        .attr("paint-order", "stroke")
        .attr("stroke", halo)
        .attr("stroke-width", haloWidth)
        .text((d, i) => L[i]);

    return svg.node();
  }
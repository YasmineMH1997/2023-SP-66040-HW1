import {getRootFromData, Tree} from './Tree'
import * as d3 from 'd3'
import * as TreeGen from "tree-json-generator";
import React, {useEffect, useRef, useState} from 'react';
import { Container, Button, TextField, listItemAvatarClasses } from '@mui/material';
import { width } from '@mui/system';
import { DataGrid } from '@mui/x-data-grid';
import './App.css';
import { red } from '@mui/material/colors';
function App() {
  const [caller, setCaller] = useState("")
  const[showForm,setShowForm] = useState(false)
  const [callee, setCallee] = useState("")
  const [calleeNode, setCalleeNode] = useState("")
  const [callerNode, setCallerNode] = useState("")
  const [redLinks, setRedLinks] = useState([])
  

  //TBD Dry 
  const rootToNodeArray = (currentNode: d3.HierarchyNode<unknown>) => {

  }

  const printNode =  (d) => {
    if(caller==="")
   { setCaller(d.target.__data__.data.name)
    setNode1(d)
  }
    else 
    {
    setCallee(d.target.__data__.data.name)
    setNode2(d)}
    setShowForm(true)
  }

  const getRootToNodePath = (nodeName:number) => {
    const root = getRootFromData(treeDataState)
    var nodes = root.descendants()
    nodes.push(root)
    var candidateNode = nodes.filter((node) => node.data.name === nodeName)[0]
    const path = []
    while (candidateNode !== root){
      path.push(candidateNode)
      candidateNode = nodes.filter((node) => node.data.name === candidateNode.parent.data.name)[0]
    }
    path.push(root)
    return path.reverse()
  }

  const moveNode = (nodeToBeMoved:string, newParent:string) => {
    const root = getRootFromData(treeDataState)
    const nodes = root.descendants()
  
    const candidateNode = nodes.find((node) => node.data.name === parseInt(nodeToBeMoved))
    if(!candidateNode?.parent)
    {
      console.log(`Error: nodeToBeMoved or newParent not found in tree data`)
      return
    }
    var oldParentNode=  candidateNode.parent
    const newParentNode = nodes.find((node) => node.data.name === parseInt(newParent))

    if (!candidateNode || !newParentNode || !oldParentNode) {
      console.log(`Error: nodeToBeMoved or newParent not found in tree data`)
      return
    }
  
    const rootToCandidate = getRootToNodePath(candidateNode.data.name)
    const rootToNewParentPath = getRootToNodePath(newParentNode.data.name)
  
    const rootData  = treeData.current
    let currNode = rootData
    let finalChild
    let i = 0
    while( i < rootToCandidate.length - 1){
      if (parseInt(currNode.name) === rootToCandidate[i].data.name){
        i++;
        finalChild = currNode.children.find((d) => parseInt(d.name) === rootToCandidate[i].data.name)
        if(finalChild.children){
          currNode = finalChild
        }
      } 
    }
  
    currNode.children.splice(currNode.children.indexOf(finalChild),1)
  
    currNode = rootData
    i = 0
    while( i < rootToNewParentPath.length-1){
      if (parseInt(currNode.name) === rootToNewParentPath[i].data.name){
        i++;
        currNode = currNode.children.find((d) => parseInt(d.name) === rootToNewParentPath[i].data.name)
      }
    }
  
    if (!currNode.children) 
      currNode.children = []
    else
    currNode.children.push(finalChild)
  
    setTreeDataState(rootData)
    // setRedLinks(redLinks => [...redLinks, {source: oldParentNode, target: newParentNode}])
    redLinks.push({source: oldParentNode, target: newParentNode})
    //setRedLinks(Object.assign([],[...redLinks,{source: oldParentNode, target: newParentNode}]))
    setRedLinks(redLinks)
    console.log("redlinks ",redLinks)
  
    try {
      const tree = Tree(treeDataState, {label: d => `${d.name}(CMR - ${(d.calls*1.0)/d.moves})`}, [], null, printNode,redLinks, simulateCalls, simulateMoves)
  
      if (currentSvg.current) {
        currentSvg.current.innerHTML = ""
        currentSvg.current.appendChild(tree)
      }
    } catch(error) {
      console.log(error)
    }

    return oldParentNode.data.name
  }
  


  const handleMove = () => {
    moveNode(caller, callee)
  }

  var initialColumns = [
    { field: 'id', headerName: 'ID', width: 70 },
    { field: 'randomName1', headerName: 'Caller', width: 130 },
    { field: 'randomName2', headerName: 'Callee', width: 130 },
    { field: 'hops', headerName: 'Hops', width: 100 },
  ];

  const [columns, setColumns] = useState(initialColumns);
  
  const [rows, setRows] = useState([])


  const updateMoveCountInTree = (nodeLabel:string, rootData) => {
    // console.log('updateCallCountInTree', rootData)
      
    // find node. BFS or DFS
    const dfs = function (start, nodeLabel) {
      //console.log("Visiting Node " + start.name);
      if (start.name === nodeLabel || start.id === nodeLabel) {
          // We have found the goal node we we're searching for
          //console.log("Found the node we're looking for!");
          //start.calls += 1
          return start;
      }
  
      // Recurse with all children
      for (var i = 0; i < start.children?.length; i++) {
          var result = dfs(start.children[i], nodeLabel);
          if (result != null) {
              // We've found the goal node while going down that child
              //result.calls +=1
              return result;
          }
      }
  
      // We've gone through all children and not found the goal node
      // console.log("Went through all children of " + start.name + ", returning to it's parent.");
      return null;
    }

    var node = dfs(rootData, nodeLabel)
    node.moves += 1
    var parent = node.parent
    console.log('parent', parent)
    while(parent!== null){
      var parentnode = dfs(rootData, parent)
      if(parentnode !== null){
        parentnode.moves += 1
        parent = parentnode?.parent
      }else{
        parent = null
      }
      
    }
    // targetNode.calls+=1
    //var parent = targetNode.parent
    //while(parent !== null){
    //  parent = targetNode.parent
    //  }
    // update count of node by 1
    // update all parent till root by 1.

    return rootData
  }

  // find node. BFS or DFS
  const dfs = function (start, nodeLabel) {
    //console.log("Visiting Node " + start.name);
    if (start.name === nodeLabel || start.id === nodeLabel) {
        // We have found the goal node we we're searching for
        //console.log("Found the node we're looking for!");
        //start.calls += 1
        return start;
    }

    // Recurse with all children
    for (var i = 0; i < start.children?.length; i++) {
        var result = dfs(start.children[i], nodeLabel);
        if (result != null) {
            // We've found the goal node while going down that child
            //result.calls +=1
            return result;
        }
    }

    // We've gone through all children and not found the goal node
    // console.log("Went through all children of " + start.name + ", returning to it's parent.");
    return null;
  }

  const updateCallCountInTree = (nodeLabel:string, rootData) => {
    // console.log('updateCallCountInTree', rootData)
      
    // find node. BFS or DFS
    const dfs = function (start, nodeLabel) {
      //console.log("Visiting Node " + start.name);
      if (start.name === nodeLabel || start.id === nodeLabel) {
          // We have found the goal node we we're searching for
          //console.log("Found the node we're looking for!");
          //start.calls += 1
          return start;
      }
  
      // Recurse with all children
      for (var i = 0; i < start.children?.length; i++) {
          var result = dfs(start.children[i], nodeLabel);
          if (result != null) {
              // We've found the goal node while going down that child
              //result.calls +=1
              return result;
          }
      }
  
      // We've gone through all children and not found the goal node
      // console.log("Went through all children of " + start.name + ", returning to it's parent.");
      return null;
    }

    var node = dfs(rootData, nodeLabel)
    node.calls += 1
    var parent = node.parent
    console.log('parent', parent)
    while(parent!== null){
      var parentnode = dfs(rootData, parent)
      if(parentnode !== null){
        parentnode.calls += 1
        parent = parentnode?.parent
      }else{
        parent = null
      }
      
    }
    // targetNode.calls+=1
    //var parent = targetNode.parent
    //while(parent !== null){
    //  parent = targetNode.parent
    //  }
    // update count of node by 1
    // update all parent till root by 1.

    return rootData
  }

  const simulateCalls = () => {
    var rootData = treeData.current
    const columns = [
      { field: 'id', headerName: 'ID', width: 70 },
      { field: 'randomName1', headerName: 'Caller', width: 130 },
      { field: 'randomName2', headerName: 'Callee', width: 130 },
      { field: 'hops', headerName: 'Hops', width: 100 },
    ];
    setColumns(columns);
    const root = d3.hierarchy(treeData.current);
    const nodes = root.descendants();
    const getNames = nodes.map((node) => node.data.name);
    let callCount = 0;
  
    const makeCall = () => {
      const randomIndex1 = Math.floor(Math.random() * getNames.length);
      const randomIndex2 = Math.floor(Math.random() * (getNames.length - 1));
      const secondRandomIndex = randomIndex2 >= randomIndex1 ? randomIndex2 + 1 : randomIndex2;
      const randomName1 = getNames[randomIndex1];
      const randomName2 = getNames[secondRandomIndex];
      console.log(`Call ${++callCount}: Random names: ${randomName1} and ${randomName2}`);
      var hops = findLCA(randomName1, randomName2);
      console.log("LCA Hops: ", hops);
      setRows(prevRows => [...prevRows, { id: prevRows.length + 1, randomName1, randomName2, hops }]);
      rootData = updateCallCountInTree(randomName1,rootData)
      rootData = updateCallCountInTree(randomName2,rootData)

      setTreeDataState(rootData)

      if (callCount < 12) {
        setTimeout(makeCall, 5000);
      }
    };
  
    makeCall();
  };

  

  const simulateReplication = () => {

    var rootData = treeData.current

    var root = d3.hierarchy(rootData);

    var nodes = root.descendants();
    var filtered_nodes = nodes.filter(node => ((node.data.calls *1.0) / node.data.moves) > 3)

    console.log('filtered_nodes', filtered_nodes)
    const getAllLeafNodes =  (node, leaves = []) => {

      if(!node.children)
        leaves.push(node.data)
      else
        for (const child of node.children){
          getAllLeafNodes(child, leaves)
        }
        return leaves
    }

    var parent_and_leaves = []
    for (const node of filtered_nodes){
      const leaves =  getAllLeafNodes(node)
      parent_and_leaves.push({target:node, leaves: leaves})
    }

    
    //= filtered_nodes.map(node => ({target: node, leaves: getAllLeafNodes(node)}))

    console.log('leaves' , parent_and_leaves)
    parent_and_leaves.forEach(node_and_leaf =>{
      //dfs(rootData, node_and_leaf.tar)
      //console.log(node_and_leaf)
      const leaves =  node_and_leaf.leaves
      const target =  node_and_leaf.target
      console.log(target)
      const replicas = leaves.map(leaf => leaf.name)
      var node = dfs(rootData, target.data.id)
      node.replicas = replicas

    }
    )

  }


  const simulateMoves = () => {
    const columns = [
      { field: 'id', headerName: 'ID', width: 70 },
      { field: 'randomName1', headerName: 'Moved Node', width: 130 },
      { field: 'oldParent', headerName: 'Old Parent', width: 130 },
      { field: 'randomName2', headerName: 'New Parent', width: 100 },
      { field: 'randomName3', headerName: 'Caller', width: 100 },
      { field: 'hops', headerName: 'Hops w/o FP', width: 100 },
      { field: 'hopsFP', headerName: 'Hops w/ FP', width: 100 },
    ];
    let moveCount = 0;

    const doMove = () => {

    var root = d3.hierarchy(treeData.current);
    var rootData = treeData.current
    var nodes = root.descendants();
    var getNames = nodes.map((node) => node.data.name);
    const randomIndex1 = Math.floor(Math.random() * getNames.length);
    const randomIndex2 = Math.floor(Math.random() * (getNames.length - 1));
    const secondRandomIndex = randomIndex2 >= randomIndex1 ? randomIndex2 + 1 : randomIndex2;
    const randomName1 = getNames[randomIndex1];
    const randomName2 = getNames[secondRandomIndex];
    const oldParent = moveNode(randomName1+"", randomName2+"" );
    rootData =updateMoveCountInTree(oldParent, rootData)
    //Get a caller to the moved node 
    root = d3.hierarchy(treeData.current);
    nodes = root.descendants();
    getNames = nodes.map((node) => node.data.name);
    // Get a random index 3 that is different from the new location of randomName1
    const randomIndex3 = Math.floor(Math.random() * getNames.length);
    const randomName3 = getNames[randomIndex3];
  
    // Add the row to the table with empty values for `hops` and `hopsFP`
    setRows(prevRows => [...prevRows, { id: prevRows.length + 1, randomName1, oldParent, randomName2, randomName3 }]);
    setTreeDataState(rootData)
   
    setTimeout(() => {
      const hops = findLCA(randomName3, randomName1);
      const hopsFP = findLCA(randomName3, oldParent) + 1;
      setRows(prevRows => prevRows.map(row => {
        if (row.randomName1 === randomName1) {
          return { ...row, hops, hopsFP };
        }
        return row;
      }));
    }, 5000);
      moveCount++
      if(moveCount < 12)
        setTimeout(doMove, 10000);
    }
    setColumns(columns);
    // After 5 seconds, update the row with the values for `hops` and `hopsFP`
   
    doMove()
  

  };
  

/*
  const simulateMoves = () => {
    var root = d3.hierarchy(treeData.current);
    var nodes = root.descendants();
    var getNames = nodes.map((node) => node.data.name);
    let callCount = 0;
  
    const makeMove = () => {
      const randomIndex1 = Math.floor(Math.random() * getNames.length);
      const randomIndex2 = Math.floor(Math.random() * (getNames.length - 1));
      const secondRandomIndex = randomIndex2 >= randomIndex1 ? randomIndex2 + 1 : randomIndex2;
      const randomName1 = getNames[randomIndex1];
      const randomName2 = getNames[secondRandomIndex];
      moveNode(randomName1+"", randomName2+"" )
      ++callCount
      //Get a caller to the moved node 
      root = d3.hierarchy(treeData.current);
      nodes = root.descendants();
      getNames = nodes.map((node) => node.data.name);
          // Get a random index 3 that is different from the new location of randomName1
      const randomIndex3 = Math.floor(Math.random() * getNames.length);
      const randomName3 = getNames[randomIndex3];
        var hops = findLCA(randomName3, randomName1);
      if (callCount < 12) {
        setTimeout(makeMove, 10000);
      }
    };
  
     makeMove();
  };*/
  
 
  const findLCA = (c1,c2) => {
    const root = getRootFromData(treeDataState)
    var nodes = root.descendants()
    var links = root.links()
    nodes.push(root)
  
    console.log(nodes)
    const firstNode = nodes.filter((node) => node.data.name === parseInt(c1))[0]
    console.log("fn",caller)
    console.log("fn",firstNode)
    const secondNode = nodes.filter((node) => node.data.name === parseInt(c2))[0]
    var LCA = undefined
    var rootToFirstNodeLink =[]
    var rootToSecondNodeLink =[]
    var current: d3.HierarchyNode<unknown>|null = firstNode
    while(current?.parent){
      rootToFirstNodeLink.push(current)
      current =  current.parent
    }
   
    rootToFirstNodeLink.reverse()
    rootToFirstNodeLink.unshift(root)
    console.log(rootToFirstNodeLink)
    var current: d3.HierarchyNode<unknown>|null = secondNode
    while(current?.parent){
      rootToSecondNodeLink.push(current)
      current =  current.parent
    }

    rootToSecondNodeLink.reverse()
    rootToSecondNodeLink.unshift(root)
     
    const intersection = rootToFirstNodeLink.filter(value => rootToSecondNodeLink.includes(value));
    LCA = intersection.pop()
  console.log("interse: ", intersection)

  var current: d3.HierarchyNode<unknown>|null = intersection
  const LCAToFirstNode = rootToFirstNodeLink.slice(rootToFirstNodeLink.indexOf(LCA))
  const LCAToSecondNode = rootToSecondNodeLink.slice(rootToSecondNodeLink.indexOf(LCA))
  console.log("Hops ", LCAToFirstNode.length+LCAToSecondNode.length-2)
  const linksFirstNode = []
  for(var i=0; i<LCAToFirstNode.length-1; i++){
      linksFirstNode.push({source:LCAToFirstNode[i], target:LCAToFirstNode[i+1]})
  }

  const linksSecondNode = []
  for(var i=0; i<LCAToSecondNode.length-1; i++){
    linksSecondNode.push({source:LCAToSecondNode[i], target:LCAToSecondNode[i+1]})
  }
  


    //updateTree for LCA
    try {
      const tree = Tree(treeDataState,{label: d => `${d.name}(CMR - ${(d.calls*1.0)/d.moves})`}, linksFirstNode.concat(linksSecondNode), LCA, printNode,redLinks, simulateCalls, simulateMoves) 
      if(currentSvg.current){
        currentSvg.current.innerHTML=""
        currentSvg.current.appendChild(tree)
      }
    }catch(error){
      console.log(error)
    }
    return LCAToFirstNode.length+LCAToSecondNode.length-2
  }




  

  
  const currentSvg = useRef(null);
  const config = {
    node: { // Node fields, required
      id: "@id()", // Pipes
      parent: "@parent()",
      level: "@level()",
      name: "@randomInteger(111111,333333)", 
      //age: "@randomInteger(14,99)",
      //email: "@randomEmail()",
      calls: 1,
      moves: 1,
      registered: "@randomBoolean(0.79)",
      children: "@child()", // Child field pointer (not required, if children are not needed)
      replicas: []
    },
    rootNodesNumber: 1, // Number of root nodes
    childNodesNumber: [2, 5], // Number of children nodes (from 2 to 5)
    hasChildRate: 0.9, // Probability of children
    maxLevel: 4 // Max nesting
  }
  
  let tree = TreeGen.generate(config);
  tree[0].parent = null
  const treeData = (useRef(tree[0]))
  

  const [treeDataState, setTreeDataState] = useState(treeData.current);
  const [node1, setNode1] = useState("")
  const [node2, setNode2] = useState("")
  useEffect(() => {
    const data = treeDataState
    const tree = Tree(data,{label: d => `${d.name}(CMR - ${(d.calls*1.0)/d.moves})`},[],null, printNode,redLinks, simulateCalls, simulateMoves)  
    if(currentSvg.current){
      currentSvg.current.innerHTML=""
      currentSvg.current.appendChild(tree)
    } 
    setTreeDataState(data)
  }, [currentSvg, treeData,caller,callee,redLinks])

  

  return (
    <>
    {(
   <Container maxWidth="xl">
   <div style={{ display: 'flex', flexDirection: 'row' }}>
   <div style={{ width: '100%', height: 400, marginRight: '10px', marginTop: '200px' }}>
  <div style={{ width: '100%', height: '100%' }}>
    <DataGrid rows={rows} columns={columns} pageSize={5} autoHeight autoWidth={true} columnBuffer={20} />
  </div>
</div>
     <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
       <h2>Calls</h2>
       <form style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
         <div style={{ display: 'flex', flexDirection: 'row', gap: '10px' }}>
           <TextField variant="standard" label="Caller Number" value={caller} disabled />
           <TextField variant="standard" label="Callee Number" name="calleeTextField" value={callee} disabled/>
         </div>
         <div style={{ display: 'flex', flexDirection: 'row', gap: '10px' }}>
           <Button variant="contained" color="success" onClick={(event) => {event.preventDefault(); simulateCalls()}}>Simulate Calls</Button>
           <Button variant="contained" color="success" onClick={(event) => {event.preventDefault(); findLCA(caller,callee)}}>Call</Button>
         </div>
         <div style={{ display: 'flex', flexDirection: 'row', gap: '10px' }}>
           <Button style={{ width: '210px' }} variant="outlined" color="error" onClick={(event)=>{event.preventDefault();handleMove()}} >Move Node</Button>
           <Button style={{ width: '210px' }} variant="outlined" color="error" onClick={(event)=>{event.preventDefault();simulateMoves()}} >Simulate Movements</Button>
           <Button style={{ width: '210px' }} variant="outlined" color="error" onClick={(event)=>{event.preventDefault();simulateReplication()}} >Simulate Replication</Button>
           <Button style={{ width: '210px' }} variant="outlined" color="error" onClick={(event)=>{event.preventDefault();setCaller("");setCallee(""); setRows([])}}>Clear</Button>
         </div>
       </form>
     </div>
   </div>
 </Container>
    )}
    <div style={{height:"100%", width:"100%", overflowY: "auto"}} id="divid" ref={currentSvg}>
      
    </div>
    {/* //value={JSON.stringify(treeDataState, null, "\t")} */}
    </>
  );
}

export default App;
